let age=20;
b=true;
if(age > 18 || b==true)
{
    console.log("I can drive");
}
else{
    console.log("I can't drive");
}