console.log("Adding two numbers");
a=6;
b=7;
console.log("c=",a+b);
console.log("c=",a-b);
console.log("c=",a*b);
console.log("c=",a/b);
console.log("c=",a%b);