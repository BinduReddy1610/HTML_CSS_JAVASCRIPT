console.log("Adding two numbers");
a=77;
b=77;
c=a+b;
console.log("c=",a+b);